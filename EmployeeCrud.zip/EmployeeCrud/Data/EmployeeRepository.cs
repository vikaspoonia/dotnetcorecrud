// This will be responsible for talking to database
//import Models folder
using System.Reflection.Metadata.Ecma335;
using EmployeeCrud.Models;
//import ADO.NET SQL server classes, it includes four classes
using Microsoft.Data.SqlClient;

namespace EmployeeCrud.Data;

public class EmployeeRepository
{
    private readonly string _connectionString;
    //IConfiguration object reads the appsettings.json file
    public EmployeeRepository(IConfiguration configuration)
    {
        _connectionString = configuration.GetConnectionString("DefaultConnection")??throw new Exception("Connection string not found");
    }

    //Testing connection to SQL Server 
  /*  public async Task TestConnectionAsync()
    {
        //We using ensures that the connection is properly disposed when we're finished with it. 
        // Create a connection object, remember creating a object not connecting it.
        using SqlConnection connection = new SqlConnection(_connectionString);
        // .OpenAsync actually opens the connection. 
        await connection.OpenAsync();
    }
*/
/*
    public async Task TestQueryAsync()
    {
        using SqlConnection connection = new SqlConnection(_connectionString);
        await connection.OpenAsync();

        string sql = "SELECT * FROM Employees";
// SqlCommand object will store the connection value and sql query
        using SqlCommand command = new SqlCommand(sql, connection);
    //ExecuteReaderAsync send sql command to the server and returns 
    //rows of the employees table which read by SqlDataReader object
    //and a result set.  
        using SqlDataReader reader = await command.ExecuteReaderAsync();
//For each read
        while(await reader.ReadAsync())
        {
            Console.WriteLine(
                $"Id:{reader["Id"]}," + 
                $"name: {reader["FirstName"]}{reader["LastName"]}"
            );
        }

    }
    */
    public async Task<List<Employee>> GetAllAsync()
    {
        List<Employee> employees = new();
        using SqlConnection connection = new SqlConnection(_connectionString);
        await connection.OpenAsync();

        string sqlstatement = @"
        SELECT * FROM Employees;
        ";
        using SqlCommand command = new SqlCommand(sqlstatement, connection);
        using SqlDataReader reader = await command.ExecuteReaderAsync();

        while(await reader.ReadAsync())
        {
            Employee employee = new Employee
            {
                Id = reader.GetInt32(0),
                FirstName = reader.GetString(1),
                LastName = reader.GetString(2),
                Email = reader.GetString(3),
                Designation = reader.GetString(4)
            };

            employees.Add(employee);
        }
        return employees;
    }

//this function will return an integer- the newly created employee id
    public async Task<int> CreateAsync(Employee employee)
    {
        //@ are the placeholders which we supply from employee object
        string sqlstatement="INSERT INTO Employees(FirstName, LastName, Email, Designation) VALUES (@FirstName, @LastName, @Email, @Designation) SELECT CAST(SCOPE_IDENTITY() AS INT);";
        using SqlConnection connection = new SqlConnection(_connectionString);
        await connection.OpenAsync();
        
        using SqlCommand command = new SqlCommand(sqlstatement, connection);
        command.Parameters.AddWithValue("@FirstName", employee.FirstName);
        command.Parameters.AddWithValue("@LastName", employee.LastName);
        command.Parameters.AddWithValue("@Email", employee.Email);
        command.Parameters.AddWithValue("@Designation", employee.Designation);
        //ExecuteScaler returns a integer
        int newId = (int)await command.ExecuteScalarAsync();
        return newId;
    }

    //Update method
    public async Task<bool> UpdateAsync(Employee employee)
    {
        using SqlConnection connection = new SqlConnection(_connectionString);
        await connection.OpenAsync();
        // Here we are updating all the fields
        string sql = "UPDATE Employees SET FirstName = @FirstName, LastName = @LastName, Email = @Email, Designation = @Designation WHERE Id =@Id";
        using SqlCommand command = new SqlCommand(sql, connection);
        command.Parameters.AddWithValue("@FirstName", employee.FirstName);
        command.Parameters.AddWithValue("@LastName", employee.LastName);
        command.Parameters.AddWithValue("@Email",employee.Email);
        command.Parameters.AddWithValue("@Designation", employee.Designation);
        command.Parameters.AddWithValue("@Id", employee.Id);
        // it returns number of rows affected
        int rowsAffected =await command.ExecuteNonQueryAsync();
        if (rowsAffected>0)
        {
            return true;
        }
        return false;


    }

    public async Task<bool> DeleteAsync(int id)
    {
        using SqlConnection connection = new SqlConnection(_connectionString);
        await connection.OpenAsync();
        string sql = "DELETE FROM Employees WHERE Id= @Id";

        using SqlCommand command = new SqlCommand(sql, connection);
        command.Parameters.AddWithValue("@Id", id);
        int rowsAffected = await command.ExecuteNonQueryAsync();
        if (rowsAffected > 0)
        {
            return true;
        }
        else
        {
            return false;
        }

        
    }
}


