// As I want to use EmployeeRepository class that is why importing
using EmployeeCrud.Data;
using EmployeeCrud.Models;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddSingleton<EmployeeRepository>();
var app = builder.Build();

//calling async function is defined in Employee repository class
/*app.MapGet("/test-db", async(EmployeeRepository repository) =>
{
    await repository.TestQueryAsync();
    return Results.Ok("Query Executed successfully");
});
*/
app.MapGet("/employees", async(EmployeeRepository repository) =>
{
    // It is of type List<Employees>
    List<Employee> employees = await repository.GetAllAsync();
    // Results.Ok sends a JSON object
    return Results.Ok(employees);
});

app.MapPost("/api/employees", async(Employee employee,EmployeeRepository repository) =>
{
    Console.WriteLine(employee);
    int newId = await repository.CreateAsync(employee);
    employee.Id = newId;
    //send HTTP 200 Ok and employee object
    return Results.Created($"/api/employees/{employee.Id}", employee);
});

app.MapPut("/api/employees/{id}",async(int id, Employee employee, EmployeeRepository repository) =>
{
    employee.Id = id;
    bool updated = await repository.UpdateAsync(employee);

    if (!updated)
    {
        return Results.NotFound();
    }
    else
    {
        return Results.Ok(employee);
    }
});

app.MapDelete("/api/employees/{id}",async(int id, EmployeeRepository repository) =>
{
    bool deleted = await repository.DeleteAsync(id);
    if (!deleted)
    {
        // HTTP response will be 404 not found
        return Results.NotFound();
    }
    return Results.NoContent();
});
app.Run();
