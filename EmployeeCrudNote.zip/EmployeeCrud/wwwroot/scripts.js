
console.log("Scripts JS loaded");

let isEditing = false;
let editingEmployeeId = null;

function showMessage(message){
    const messageElement = document.getElementById("message");
    messageElement.textContent = message;
    messageElement.classList.remove("d-none");
}

async function loadEmployees(){
    const response = await fetch("/employees");
    if(!response.ok){
        console.log("Error in loading employees");
        return;
    }
    const employees = await response.json();
    
    console.log(employees);
    const tableBody = document.getElementById("employeeTableBody");
    //clear exisiting table
    tableBody.innerHTML="";
    employees.forEach(employee => {
        const row = document.createElement("tr");

        const idCell = document.createElement("td");
        idCell.textContent = employee.id;
        row.appendChild(idCell);

        const firstNameCell = document.createElement("td");
        firstNameCell.textContent = employee.firstName;
        row.appendChild(firstNameCell);
        
        const lastNameCell = document.createElement("td");
        lastNameCell.textContent = employee.lastName;
        row.appendChild(lastNameCell);

        const emailCell = document.createElement("td");
        emailCell.textContent = employee.email;
        row.appendChild(emailCell);

        const designationCell = document.createElement("td");
        designationCell.textContent = employee.designation;
        row.append(designationCell);
        // created a new cell named action which will include delete and edit
        const actionCell = document.createElement("td");
       
        //create element button, name the button and append it to action cell element
        const editButton = document.createElement("button");
        editButton.textContent = "Edit";
        editButton.classList.add("btn","btn-warning", "me-2");
        editButton.addEventListener("click", ()=>{
            console.log("Inside editButton");
            console.log(employee);
           document.getElementById("firstName").value = employee.firstName;
           document.getElementById("lastName").value = employee.lastName;
           document.getElementById("email").value = employee.email;
           document.getElementById("designation").value = employee.designation;
            isEditing = true;
            editingEmployeeId = employee.id;
            document.getElementById("formTitle").textContent = "Edit Employee Record: "+employee.firstName+" "+employee.lastName+" "+employee.designation;
            document.getElementById("submitButton").textContent ="Update Employee";
        });
        
        actionCell.appendChild(editButton);
        //delete button
        const deleteButton = document.createElement("button");
        deleteButton.textContent="Delete";
        deleteButton.classList.add("btn", "btn-danger");
        deleteButton.addEventListener("click", async()=>{
            console.log(employee.id);

            const response = await fetch(`/api/employees/${employee.id}`,{
                method: "DELETE"

            });
            if(!response.ok){
                console.log("Failed to delete employee");
                showMessage("Failed to delete employee.");
                return;
            }

            loadEmployees();
            showMessage("Employee successfully deleted");
            

        });
        actionCell.appendChild(deleteButton);
        // added to row but in memeory
        row.appendChild(actionCell);
        // Add the row into the actual table. 
        tableBody.appendChild(row);
    });
}



async function addEmployee(event){
    console.log("addEmployee called");
    event.preventDefault();
    //testing editing mode
   if(isEditing){
        console.log("Update mode is on");
        const firstName = document.getElementById("firstName").value;
        const lastName = document.getElementById("lastName").value;
        const email = document.getElementById("email").value;
        const designation = document.getElementById("designation").value;
        const employee = {
            id: editingEmployeeId,
            firstName: firstName,
            lastName: lastName,
            email: email,
            designation: designation,

        }
        const jsonData = JSON.stringify(employee);
        const response =await fetch(`/api/employees/${editingEmployeeId}`,{
            method: "PUT",
            headers:{
                "Content-Type":"application/json",
            },
            body:jsonData

        });
        if(!response.ok){
            console.log("Failed to add employee");
            return;
        }
        const result =await response.json();
        console.log(result);
        loadEmployees();
        showMessage("Employee successfully updated")
        isEditing = false;
        editingEmployeeId = null;
        document.getElementById("formTitle").textContent = "Add Employee";
        document.getElementById("submitButton").textContent = "Add Employee"
        document.getElementById("employeeForm").reset();
        


        return;
    }

    const firstName = document.getElementById("firstName").value;
    const lastName = document.getElementById("lastName").value;
    const email = document.getElementById("email").value;
    const designation = document.getElementById("designation").value;
// JavaScript object then  convert JavaScript object to JSON using stringfy method
    const employee = {
        firstName: firstName,
        lastName: lastName,
        email: email,
        designation: designation
    }
    //JSON stringify method
    const jsonData = JSON.stringify(employee);
    console.log(jsonData);
    const response = await fetch("/api/employees", {
        method:"POST",
        headers:{
            "Content-Type":"application/json"
        },
        body:jsonData
    });

    if(!response.ok){
        showMessage("Failed to add employee.")
        console.log("Failed to add employee.");
        return;
    }
    const result = await response.json();
    console.log(result)
    loadEmployees();
    showMessage("Employee added successfully")

}

async function updateEmployee(){

}

loadEmployees();